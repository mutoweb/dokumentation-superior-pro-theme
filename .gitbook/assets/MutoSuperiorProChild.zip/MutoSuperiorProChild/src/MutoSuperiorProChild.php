<?php declare(strict_types=1);

namespace Muto\SuperiorProChild;

use Shopware\Core\Framework\Plugin;
use Shopware\Storefront\Framework\ThemeInterface;

class MutoSuperiorProChild extends Plugin implements ThemeInterface
{
}
